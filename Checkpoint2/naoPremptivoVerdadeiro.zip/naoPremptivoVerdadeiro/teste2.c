#include<stdio.h> 
#include<unistd.h>
#include <time.h>

int main(int argc, char* argv[])
{
	clock_t begin = clock();
	for(int i = 1;i <= 2000000000;i++){
		//printf("((argc %i))",argc);	
    		if(i%500000000 == 0){
			printf("Processo 2: %d\n", i);
		}
		//usleep(1000000);
		for(int i = 0;i<2;i++){
		}

	}
	clock_t end = clock();
	printf("Processo 2 Tempo: %f\n", (double)(end-begin));
	return 0;
}
