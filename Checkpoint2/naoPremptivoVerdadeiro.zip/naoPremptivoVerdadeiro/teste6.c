#include<stdio.h> 
#include<unistd.h>
#include <time.h>

int main(int argc, char* argv[])
{
	clock_t begin = clock();
	for(int i = 1;i <= 1000000000;i++){
		//printf("((argc %i))",argc);	
    		if(i%125000000 == 0){
			printf("Processo 6: %d\n", i);
		}
		//usleep(1000000);
		for(int i = 0;i<20;i++){
		}

	}
	clock_t end = clock();
	printf("Processo 6 Tempo: %f\n", (double)(end-begin));
	return 0;
}
