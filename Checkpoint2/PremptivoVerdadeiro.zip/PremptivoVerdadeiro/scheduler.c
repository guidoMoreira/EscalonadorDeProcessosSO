#include "scheduler.h"
#include "load_jobs.h"
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


clock_t begin;
clock_t end;
extern void iniciarProcesso(int index);

int countConcluido;

int timer = 0;
int *chegou;
void scheduler_init(char* jobs, float quantum){

	pidx = 0;
	alterna = 0;
	receive=0;	

	loadJobs(jobs);

	/*print_jobsQueue();*/


	countConcluido = queueSize;
	int i;
	chegou = (int*)malloc(sizeof(int)*queueSize);

	for(i = 0; i < queueSize; i++){
			chegou[i] = 0;
			iniciarProcesso(i);
			kill(spid[i], SIGSTOP);
	}		
	Terminados[0] = 1;
	chegou[0] = 1;
	//printf("%i>>",Terminados[alterna]);
	//kill(spid[alterna], SIGCONT);
	while(countConcluido >=0){
		for(int i = 0; i < queueSize;i++){
			printf("%i ", chegou[i]);		
		}printf("\n");
		  signal(SIGALRM, alternaTarefa);
		  alarm(quantum);
		  while(!receive)
			pause();
		  receive = 0;
		  printf("%i\n\n",timer);
		timer++;
		sleep(1);
		switch(timer){
			case 1:
				chegou[1] = 1;
				break;
			case 20:
				chegou[2] = 1;
				break;
			case 25:
				chegou[3] = 1;
				break;
			case 35:
				chegou[4] = 1;
				break;
			case 40:
				chegou[5] = 1;
				break;
			case 10:
				chegou[6] = 1;
				break;

			case 2:
				chegou[7] = 1;
				break;
			case 7:
				chegou[8] = 1;
				break;
			case 21:
				chegou[9] = 1;
				break;
		}
    }


}


void alternaTarefa(int signum){	

	UNUSED(signum);
	//if(TarefaConcluida[alterna]){
		//countConcluido--;
		receive = 1;	
		kill(spid[alterna], SIGSTOP);//Pausa tarefa alternada
		
		int menor = 0;
		if(times[0]<=0){
		for(int i = 0;i < queueSize;i++){
			if(times[i] <= 0){Terminados[i] = 1;}
			if(times[menor] <= 0){menor++;}
			if(Terminados[i] <= 0 && times[menor] > times[i] && chegou[i]==1){
				menor = i; 
			}
		}
		}else{menor = 0;}
		if(menor < queueSize){
			if(chegou[menor]==1){
			alterna = menor;
			times[menor]-=(2000000);

			kill(spid[alterna], SIGCONT);//Continua tarefa alternada
			}
		}else{countConcluido =-1;}
		//printf("Testa deu o tempo");
		//printf("Atual: %f",times[alterna]);
}


