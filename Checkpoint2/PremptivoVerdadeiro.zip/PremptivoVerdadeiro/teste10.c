#include<stdio.h> 
#include<unistd.h>
#include <time.h>

int main(int argc, char* argv[])
{
	clock_t begin = clock();
	for(int i = 1;i <= 150000000;i++){
		//printf("((argc %i))",argc);	
    		if(i%62500000 == 0){
			printf("Processo 10: %d\n", i);
		}
		//usleep(1000000);

	}
	clock_t end = clock();
	printf("Processo 10 Tempo: %f\n", (double)(end-begin));
	return 0;
}
